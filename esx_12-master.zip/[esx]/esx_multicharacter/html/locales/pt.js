const translate = new Object();

translate.name = "Nome";
translate.job = "Trabalho";
translate.bank = "Banco";
translate.money = "Dinheiro";
translate.gender = "Género";
translate.dob = "Data de Nascimento";
