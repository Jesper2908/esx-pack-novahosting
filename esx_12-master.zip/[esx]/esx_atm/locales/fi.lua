Locales['fi'] = {
  ['invalid_amount'] = '~r~Tuo oli virheellinen summa!~s~',
  ['deposit_money']  = 'sinä talletit ~g~$%s~s~',
  ['withdraw_money'] = 'sinä nostit ~g~$%s~s~',
  ['press_e_atm']    = 'paina ~INPUT_PICKUP~ talletaaksesi tai nostaaksesi ~g~Automaatilta~s~',
  ['atm_blip']       = 'Automaatti',
}
