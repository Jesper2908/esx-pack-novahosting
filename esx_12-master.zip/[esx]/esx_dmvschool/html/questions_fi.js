var tableauQuestion = [
	{
		question: "Jos ajat 80km/h ja vastaan on tulossa asutus alue mitä teet ?",
		propositionA: "Painat kaasua että pääset mahollisimman nopeaa pois",
		propositionB: "Voit ajaa samaa vauhtia jos alueella ei ole muita autoja",
		propositionC: "Sinun pitää hidastaa",
		propositionD: "Voit jatkaa samaan malliin",
		reponse: "C"
	},

	{
		question: "Kun olet kääntymässä vasemmalle vihreistä valoista, näet jalankulkian jalkakäytävällä. Kummalla on lupa mennä ensin.",
		propositionA: "Jalankulkijalla koska he voivat mennä tien yli millä valoilla tahansa",
		propositionB: "Sinulla koska valo oli vihreä",
		propositionC: "Jalankulkijalla, koska hänellä palaa vihreä valo",
		propositionD: "Sinulla koska ajoneuvolla on aina oikeus ensin",
		reponse: "C"
	},

	{
		question: "Muualla ilmoittamatta, sallittu nopeus asutusalueella on ____ km/h.",
		propositionA: "50",
		propositionB: "55",
		propositionC: "65",
		propositionD: "70",
		reponse: "A"
	},

	{
		question: "Ennen jokaista kaistan vaihtoa, sinun pitäisi?",
		propositionA: "Katsoa peilit",
		propositionB: "Katsoa kuolleet kulmat",
		propositionC: "Näyttää vilkuilla mitä aijot tehdä",
		propositionD: "Kaikki yllä mainitut",
		reponse: "D"
	},

	{
		question: "Minkä veren alkoholipitoisuus luokitellaan päihtyneeksi?",
		propositionA: "0.2 promillea",
		propositionB: "0.8 promillea",
		propositionC: "0.5 promillea",
		propositionD: "0.4 promillea",
		reponse: "C"
	},

	{
		question: "Sinun on vedettävä sivuun ja pysähtyä, kunnes hälyytysajoneuvo on ajanut ohi sireenit päällä, ellei:",
		propositionA: "Sinulla ole kiirre",
		propositionB: "Jos hälyytysajoneuvolla on toisella kaistalla tilaa",
		propositionC: "Olet koulunalueella",
		propositionD: "Olet risteyksessä",
		reponse: "D"
	},

	{
		question: "Täytyykö poliisin vilkkuviin valoihin pysähtyä jos ne seuraavat sinua?",
		propositionA: "Ei, jos poliisilla ei ole sireenejä päällä",
		propositionB: "Kyllä",
		propositionC: "Riippuu tilanteesta",
		propositionD: "Ei",
		reponse: "B"
	},

	{
		question: "Mikä seuraavista on sallittua kun aloitat ohittaan ajoneuvoa?",
		propositionA: "Ajaminen lähellä ennen ohitusta",
		propositionB: "Koitat ajaa katukivetyksen kautta",
		propositionC: "Ajaminen vastakkaisella kaistalla",
		propositionD: "Nopeusrajoituksen ylittäminen",
		reponse: "A"
	},

	{
		question: "Ajat moottoritiellä, jonka nopeus on 120 km/h. Suurinosa liikenteestä ajaa 130km/h, joten sinun ei pitäisi ajaa nopeampaa kuin",
		propositionA: "80 kmh",
		propositionB: "40 kmh",
		propositionC: "50 kmh",
		propositionD: "120 kmh",
		reponse: "D"
	},

	{
		question: "Kun sinut ohittaa toinen ajoneuvo, mitä sinun EI pitäisi tehdä?",
		propositionA: "Hiljentää",
		propositionB: "Tarkistaa peilit",
		propositionC: "Katsot toista kuskia",
		propositionD: "Kiihdyttää",
		reponse: "D"
	},
]
