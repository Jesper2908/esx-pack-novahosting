fx_version 'adamant'

game 'gta5'

description 'ESX Boilerplate'

server_scripts {
	'server/main.lua'
}

client_scripts {
	'client/main.lua'
}
