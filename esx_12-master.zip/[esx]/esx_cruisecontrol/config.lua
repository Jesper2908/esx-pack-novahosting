Config = {}
Config.Locale = 'en'

Config.ToggleKey = "CAPITAL"
