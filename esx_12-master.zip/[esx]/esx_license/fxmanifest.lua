fx_version 'adamant'

game 'gta5'

description 'ESX License'

version '1.5.0'

server_scripts {
	'@async/async.lua',
	'@es_extended/imports.lua',
	'@oxmysql/lib/MySQL.lua',
	'server/main.lua'
}
